package com.qingluan.aigent.agent;

public enum AgentStatus {

    FREE,

    RUNNING,

    FINLISH,

    ERROR;

}
