package com.qingluan.aigent.demo.invoke;

public class OllamaInvoke {
}
