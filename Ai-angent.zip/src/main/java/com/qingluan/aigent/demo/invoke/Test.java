package com.qingluan.aigent.demo.invoke;

public interface Test {
    String API_KEY = "sk-ff091f3e0df24763ab66adaf700cb2b3";
}
