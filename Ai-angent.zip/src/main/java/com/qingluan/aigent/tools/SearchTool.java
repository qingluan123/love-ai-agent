package com.qingluan.aigent.tools;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class SearchTool {

    private static final String SEARCH_URL = "https://www.searchapi.io/api/v1/search";

    private final String apikey;

    public SearchTool(String apikey){
        this.apikey = apikey;
    }

    @Tool(description = "Search information from baidu engine")
    public String webSearch(@ToolParam(description = "Search query keyword") String query){
        //需要传入的参数
        Map<String,Object> mapparms = new HashMap<>();
        mapparms.put("q",query);
        mapparms.put("api_key",apikey);
        mapparms.put("engine","baidu");
        try {
            //发起http的get请求得到数据
            String respone = HttpUtil.get(SEARCH_URL, mapparms);
            //解析数据
            JSONObject jsonObject = JSONUtil.parseObj(respone);
            JSONArray organic_results = jsonObject.getJSONArray("organic_results");
            List<Object> objects = organic_results.subList(0, 5);

            String result = objects.stream().map(obj -> {
                JSONObject tmpjson = (JSONObject) obj;
                return tmpjson.toString();
            }).collect(Collectors.joining(","));
            return result;
        } catch (Exception e) {
            return "Search fail from Baidu" + e.getMessage();
        }
    }
}
