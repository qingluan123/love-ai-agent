package com.qingluan.aigent.tools;

public interface FileConstant {
    String FILE_SAVE_DIR = System.getProperty("user.dir") + "/tmp";
}
